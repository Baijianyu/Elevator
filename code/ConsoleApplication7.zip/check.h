#pragma once
int checkinstruct(CONF *data);
