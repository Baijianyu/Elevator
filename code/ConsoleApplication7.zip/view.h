#pragma once
int view(CONF *data);
