#pragma once
int fillform(CONF *data);
