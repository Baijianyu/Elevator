#pragma once
int change(CONF *data);
